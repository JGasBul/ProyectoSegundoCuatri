//----------------------------------------------------------------------------------------------------------------------
//region ---EnviarLogin---
function enviarLogin(event){
    event.preventDefault() //Esto previene su comportamiento normal, es decir, que no se envia
    console.log("Login enviado")

    //region ---NombreYContraseñaUsuario_URL---
    let email=document.getElementById( "email").value
    let passEmail=document.getElementById("contrasenya").value
    let url= "api/v0.0/" + email + "-" + passEmail + ".json"
    console.log(url)
    //endregion

    //region ---MétodoFetch()---
    //Si los datos recogidos no son los que tocan, fetch() nos dará un error 404 "Not Found"
    fetch(url).then(function(respuesta) {
        return respuesta.json() //Una vez recibida la respuesta, la convierto a .json
    }).then(function(datos) {
        console.log(datos.nombre)
        location.href="app/test-formulario.html"
    }).catch(function(){
        document.getElementById("error").style.visibility="visible"
    })
    //endregion
}
//endregion
//----------------------------------------------------------------------------------------------------------------------
let ojoActivo="A"
function MostrarOcultarPassword(ojo){
    if(ojoActivo==ojo){ }
    else {
        let visible = document.querySelector(".activo");
        visible.classList.remove("activo");
        let mostrar = document.querySelector(ojo+"#contenido");
        mostrar.classList.add("activo");
        ojoActivo = ojo;
        }
}